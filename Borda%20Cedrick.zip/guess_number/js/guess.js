let tries = 5;
    function checkNumber () {
    const guessNumber = document.getElementById('guess').value;

    if (tries > 0){
        if (guessNumber == random) {
     
            document.getElementById('message').innerHTML = "correct";
           
    }
    
    else if (guessNumber > random){
        document.getElementById('message').innerHTML = "Lower";
    }

    else {
        document.getElementById('message').innerHTML = "Higher";
    }
    tries--;

    document.getElementById('tries').innerHTML = "Tries left:" + tries;
}

    if (tries === 0 && guessNumber != random){
        document.getElementById('message').innerHTML = "Game Over";
    }
   
} 